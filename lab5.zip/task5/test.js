const fs = require('fs');
const path = require('path');

function readDirectoryAsync(directoryPath) {
  fs.readdir(directoryPath, { withFileTypes: true }, (err, files) => {
    if (err) {
      console.error(`Error reading directory: ${err}`);
      return;
    }

    console.log(`Contents of directory '${directoryPath}':`);
    files.forEach((file) => {
      const filePath = path.join(directoryPath, file.name);
      if (file.isDirectory()) {
        console.log(`[Directory] ${file.name}`);
        readDirectoryAsync(filePath);
      } else {
        console.log(`[File] ${file.name}`);
      }
    });
  });
}

const directoryPath = 'js';
readDirectoryAsync(directoryPath);
