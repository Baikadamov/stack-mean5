const fs = require('fs');
const path = require('path');

function removeFileOrDirectory(targetPath) {
  fs.stat(targetPath, (err, stats) => {
    if (err) {
      console.error(`Error getting file/directory info: ${err}`);
      return;
    }

    if (stats.isFile()) {
      fs.unlink(targetPath, (err) => {
        if (err) {
          console.error(`Error removing file: ${err}`);
        } else {
          console.log(`File '${targetPath}' has been successfully removed.`);
        }
      });
    } else if (stats.isDirectory()) {
      fs.rmdir(targetPath, { recursive: true }, (err) => {
        if (err) {
          console.error(`Error removing directory: ${err}`);
        } else {
          console.log(`Directory '${targetPath}' has been successfully removed.`);
        }
      });
    }
  });
}

const targetPath = 'js/test.html';
removeFileOrDirectory(targetPath);
