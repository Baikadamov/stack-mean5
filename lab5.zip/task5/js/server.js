const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
  if (req.method === 'POST') {
    let data = '';

    req.on('data', chunk => {
      data += chunk;
    });

    req.on('end', () => {
      fs.appendFile('../output.txt', data + '\n', 'utf8', err => {
        if (err) {
          console.error(`Error writing to file: ${err}`);
          res.writeHead(500, {'Content-Type': 'text/plain'});
          res.end('Internal Server Error');
          return;
        }

        res.writeHead(200, {'Content-Type': 'text/plain'});
        res.end('Data written to file successfully!\n');
      });
    });
  } else {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('Hello, World!\n');
  }
});

const port = 8080;
server.listen(port, () => {
  console.log(`Server started at: ${port}`);
});
