console.log("Node.js RUNNING!");

const fs = require('fs');

function readAndPrintFileContents(filePath) {
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error(`Error reading file: ${err}`);
      return;
    }
    console.log(`File Contents:\n${data}`);
  });
}

readAndPrintFileContents('../text.txt');
