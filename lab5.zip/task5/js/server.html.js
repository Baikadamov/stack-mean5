const http = require('http');
const fs = require('fs');

console.log("Привет, Клиент!")

const server = http.createServer((req, res) => {
  const filePath = '../static/index.html';

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error(`Error reading file: ${err}`);
      res.writeHead(500, {'Content-Type': 'text/plain'});
      res.end('Internal Server Error');
      return;
    }

    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(data);
  });
});

const port = 8080;
server.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
